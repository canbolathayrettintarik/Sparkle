import requests
import time
from DataModels import Vulnerability

class NISTClient:
    def __init__(self, api_key: str = None):
        self.base_url = "https://services.nvd.nist.gov/rest/json/cves/2.0"
        self.headers = {"apiKey": api_key} if api_key else {}

    def search_vulnerabilities(self, service_name: str, version: str):
        if not version or "Unknown" in version:
            return []

       
        query = f"{service_name} {version}"
        params = {"keywordSearch": query}

        try:
             
            response = requests.get(self.base_url, params=params, headers=self.headers, timeout=10)
            
            if response.status_code == 200:
                return self._parse_response(response.json())
            elif response.status_code == 403:
                print("[!] NIST API Rate Limit aşıldı. Bekleniyor...")
                time.sleep(10)
            return []
        except Exception as e:
            print(f"----API eror: {e}")
            return []

    def _parse_response(self, data):
        
        vulnerabilities = []
        vulnerabilities_list = data.get('vulnerabilities', [])

        for item in vulnerabilities_list:
            cve_data = item.get('cve', {})
            
            
            metrics = cve_data.get('metrics', {}).get('cvssMetricV31', [{}])[0]
            cvss_data = metrics.get('cvssData', {})
            
            vuln = Vulnerability(
                cve_id=cve_data.get('id'),
                cvss_score=float(cvss_data.get('baseScore', 0.0)),
                severity=cvss_data.get('baseSeverity', 'UNKNOWN'),
                description=cve_data.get('descriptions', [{}])[0].get('value', 'No description')
            )
            vulnerabilities.append(vuln)
        
        return vulnerabilities