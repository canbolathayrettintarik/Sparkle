from DataModels import Host, Port, Vulnerability
from api_client import NISTClient
import asyncio
 
 
from core_engine import BlueScanner

class ScannerController:
    def __init__(self, target_ip: str, target_name: str = ""):
        self.target_ip = target_ip
        self.target_name = target_name or target_ip
        self.current_host = Host(ip_address=self.target_ip, hostname=self.target_name)

    def _map_results_to_objects(self, raw_results: dict, syn_info: dict):
       
        if not self.current_host.os_info and syn_info:
            for port_num, info in syn_info.items():
                if info.get("os_guess") and info.get("os_guess") != "Unknown":
                    self.current_host.os_info = info.get("os_guess")
                    break 
        nist = NISTClient()
       #port and vuln. objects
        for port_num, port_data in raw_results.items():
            
            new_port = Port(
                number=port_num,
                protocol="TCP",
                state="open",
                service_name=port_data.get('service', 'Unknown'),
                service_version=port_data.get('version', 'Unknown')
            )
            version = new_port.service_version
            if version and version != "Unknown" and "Filtered" not in version:
                print(f"[*] {new_port.service_name} {version} için zafiyetler sorgulanıyor...")
            
            found_vulns = nist.search_vulnerabilities(new_port.service_name, version)
            
            for cve_item in port_data.get('cve', []):
                new_vuln = Vulnerability(
                    cve_id=cve_item.get('cve', 'Unknown'),
                    cvss_score=0.0, 
                    severity=cve_item.get('severity', 'INFO'),
                    description=cve_item.get('remediation', 'Açıklama bulunamadı')
                )
            
                new_port.vulnerabilities.append(new_vuln)

                
            new_port.vulnerabilities.extend(found_vulns)    
           
            self.current_host.ports.append(new_port)
    
    def execute_scan_pipeline(self, start_port: int = 1, end_port: int = 1000):
        
        class ScanArgs:
            target = self.target_ip
            start = start_port
            end = end_port
            ports = None
            top_ports = False
            compare = None
            chunk = 500
            workers = 4
            concurrency = 50
            webhook = None

       
        scanner = BlueScanner(ScanArgs())

       
        ports_to_scan = list(range(start_port, end_port + 1))
        open_ports = scanner.syn.run(ports_to_scan)
        
        if not open_ports:
            return self.current_host 
            
       
        scan_results = asyncio.run(scanner.grabber.run(open_ports))
        
        self._map_results_to_objects(raw_results=scan_results, syn_info=scanner.syn.port_info)
        
        return self.current_host

    